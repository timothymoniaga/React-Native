export type Routes = {
  Examples: undefined;
  Headspace: undefined;
};
